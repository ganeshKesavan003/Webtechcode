let menu=document.getElementById("menuline");
let ul=document.getElementById("navigation");
menu.addEventListener("click",()=>{
    ul.classList.toggle("nv")   
})
var shop=document.getElementById("btn1");
var even=document.getElementById("btn2");

var shopImage1=document.querySelector(".cover .totalCart .img #img1");
var shopImage2=document.querySelector(".cover .totalCart .img #img2");

var content1=document.querySelector(".changeCont1");
var amt1=document.querySelector(".changeAmt1");
var content2=document.querySelector(".changeCont2");
var amt2=document.querySelector(".changeAmt2");
var cover=document.querySelector(".cover");

shop.addEventListener("click",()=>{
    // shopImage1.src="images/img3.jpg";
    // shopImage2.src="images/img4.jpg";
    shopImage1.setAttribute("src","images/img3.jpg");
    content1.textContent="Air ports"
    amt1.textContent="Rs.2,500"
    shopImage2.setAttribute("src","images/img4.jpg");
    content2.textContent="Air ports pro"
    amt2.textContent="Rs.2,200"}) 
even.addEventListener("click",()=>{
    shopImage1.setAttribute("src","images/img1.jpg");
    content1.textContent="I Watch"
    amt1.textContent="Rs.22,000"
    shopImage2.setAttribute("src","images/img2.jpg");
    content2.textContent="i Watch pro"
    amt2.textContent="Rs.46,000"
})
let AddCart=document.querySelectorAll(".private-cart");
var dynamiCart=document.querySelector(".adcart");
console.log(content1.innerText)
AddCart.forEach((cart)=>{
    cart.addEventListener("click",()=>{
        if(!shopImage1.src=="" && !shopImage2.src==""){
        let adcartDetail= cart.parentNode.parentNode.parentNode
        let cartImg=adcartDetail.querySelector(".img img").src
        let cartName=adcartDetail.querySelector(".detailContent .changeCont1").textContent
        let cartAmount=adcartDetail.querySelector(".detailContent .changeAmt1").textContent
        let added=stored(cartImg,cartName,cartAmount);
        let newElement=document.createElement("div")
        newElement.innerHTML=added
        dynamiCart.append(newElement)
        }
        else{
            alert("Empty cart cannot add")
        }
    })
})
function stored(cartImg,cartName,cartAmount){
    return `
    <div class="ad">
    <div class="adimg">
        <img src=${cartImg} alt="img">
    </div>
    <div class="contcard"><h4>${cartName}</h4></div>
    <div class="contamt">${cartAmount}</div>
</div>
    `
}
AddCart.forEach((cart)=>{
    cart.addEventListener("click",()=>{
        if(!shopImage1.src=="" && !shopImage2.src==""){
        let adcartDetail2= cart.parentNode.parentNode.parentNode
        let cartImg2=adcartDetail2.querySelector(".img img").src
        let cartName2=adcartDetail2.querySelector(".detailContent .changeCont2").textContent
        let cartAmount2=adcartDetail2.querySelector(".detailContent .changeAmt2").textContent
        let added2=stored2(cartImg2,cartName2,cartAmount2);
        let newElement2=document.createElement("div")
        newElement2.innerHTML=added2
        dynamiCart.append(newElement2)
        }
        else{
            alert("Empty cart cannot add")
        }
    })
})
function stored2(cartImg2,cartName2,cartAmount2){
    return `
    <div class="ad">
    <div class="adimg">
        <img src=${cartImg2} alt="img">
    </div>
    <div class="contcard"><h4>${cartName2}</h4></div>
    <div class="contamt">${cartAmount2}</div>
</div>
    `
}
